import time

def matrix_chain_multiplication(p):
    n = len(p) - 1

    # DP table
    dp = [[0 for _ in range(n)] for _ in range(n)]

    # Chain length
    for length in range(2, n + 1):
        for i in range(n - length + 1):
            j = i + length - 1
            dp[i][j] = float('inf')

            for k in range(i, j):
                cost = (dp[i][k] +
                        dp[k + 1][j] +
                        p[i] * p[k + 1] * p[j + 1])

                dp[i][j] = min(dp[i][j], cost)

    return dp[0][n - 1]


# User input
n = int(input("Enter number of matrices: "))

print("Enter", n + 1, "dimensions:")
p = list(map(int, input().split()))

# Check input
if len(p) != n + 1:
    print("Error: You must enter exactly", n + 1, "dimensions.")
else:
    # Start execution time
    start_time = time.perf_counter()

    result = matrix_chain_multiplication(p)

    # End execution time
    end_time = time.perf_counter()

    print("\nMinimum number of scalar multiplications:", result)
    print("Execution time:", end_time - start_time, "seconds")

    print("\nTime Complexity: O(n^3)")
    print("Space Complexity: O(n^2)")