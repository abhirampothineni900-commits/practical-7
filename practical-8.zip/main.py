import time

def dfs(graph, node, visited):
    visited.add(node)
    print(node, end=" ")

    for neighbor in graph[node]:
        if neighbor not in visited:
            dfs(graph, neighbor, visited)


# User input
n = int(input("Enter number of vertices: "))

graph = {}

for i in range(n):
    graph[i] = []

# Enter edges
e = int(input("Enter number of edges: "))

print("Enter edges (source destination):")

for _ in range(e):
    u, v = map(int, input().split())
    graph[u].append(v)
    graph[v].append(u)   # Remove this line for directed graph

start = int(input("Enter starting vertex: "))

# DFS execution
visited = set()

start_time = time.perf_counter()

print("\nDFS Traversal:")
dfs(graph, start, visited)

end_time = time.perf_counter()

print("\n\nExecution time:", end_time - start_time, "seconds")
print("Time Complexity: O(V + E)")
print("Space Complexity: O(V)")