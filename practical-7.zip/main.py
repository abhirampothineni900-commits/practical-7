import time

def coin_change(amount, coins):
    # dp[i] = minimum number of coins needed for amount i
    dp = [float('inf')] * (amount + 1)
    dp[0] = 0

    for i in range(1, amount + 1):
        for coin in coins:
            if coin <= i:
                dp[i] = min(dp[i], dp[i - coin] + 1)

    return dp[amount] if dp[amount] != float('inf') else -1


# User input
coins = list(map(int, input("Enter coin denominations separated by spaces: ").split()))
amount = int(input("Enter the amount: "))

# Start execution time
start_time = time.perf_counter()

result = coin_change(amount, coins)

# End execution time
end_time = time.perf_counter()

# Output
if result == -1:
    print("Amount cannot be formed using the given coins.")
else:
    print("Minimum number of coins required:", result)

print("Execution time:", end_time - start_time, "seconds")